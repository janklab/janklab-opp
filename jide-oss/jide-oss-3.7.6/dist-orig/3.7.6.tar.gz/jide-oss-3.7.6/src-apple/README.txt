#
# Fake apple / com.apple source code (from openjdk) to let jide-oss build on jdk8
#
# these classes are not packaged in jide-oss-x.y.jar
