/**
 * The package contains classes for IntelliHints for JIDE Common Layer.
 */
package com.jidesoft.hints;