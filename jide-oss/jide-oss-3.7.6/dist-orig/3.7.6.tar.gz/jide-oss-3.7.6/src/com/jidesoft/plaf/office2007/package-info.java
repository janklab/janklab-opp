/**
 * The package contains ComponentUI implementation for Office2007 style.
 */
package com.jidesoft.plaf.office2007;