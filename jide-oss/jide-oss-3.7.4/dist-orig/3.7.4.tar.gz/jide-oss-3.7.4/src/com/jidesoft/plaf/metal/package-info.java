/**
 * The package contains ComponentUI implementation for Metal style.
 */
package com.jidesoft.plaf.metal;