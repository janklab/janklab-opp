/**
 * The package contains classes related to Range for JIDE Charts and JIDE Gantt Chart product.
 */
package com.jidesoft.range;